<?php


require_once 'connect.php';

global $conn;
$sql="SELECT * FROM `table3` ";

$result=mysqli_query($conn,$sql);

//create an array
$emparray = array();
while($row =mysqli_fetch_assoc($result))
{
    $emparray[] = $row;
}


echo "</pre>";
var_dump( json_encode($emparray))."<br>";

