<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kurs_ishi";

$conn = new mysqli($servername, $username, $password, $dbname);

$id=$_GET['id'];
$sql="DELETE FROM `xabar` WHERE id='$id'";
$result=mysqli_query($conn,$sql);
if($result){
    header("location:admin.php");
}
else {
    echo "Failed".mysqli_error($conn);
}

?>