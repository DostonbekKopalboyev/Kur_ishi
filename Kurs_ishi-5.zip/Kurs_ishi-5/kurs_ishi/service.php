<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Woody - Carpenter Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700;900&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
<!-- Spinner Start -->
<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
    <div class="spinner-grow text-primary" style="width: 3rem; height: 3rem;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<!-- Spinner End -->


<!-- Topbar Start -->
<div class="container-fluid bg-light p-0">
    <div class="row gx-0 d-none d-lg-flex">
        <div class="col-lg-7 px-5 text-start">
            <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                <small class="fa fa-map-marker-alt text-primary me-2"></small>
                <small>Xorazm, Yangiariq, Shirsholi</small>
            </div>
            <div class="h-100 d-inline-flex align-items-center py-3">
                <small class="far fa-clock text-primary me-2"></small>
                <small>Dushshanba - Shanba : 08:30 dan - 18:00 gacha</small>
            </div>
        </div>
        <div class="col-lg-5 px-5 text-end">
            <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                <small class="fa fa-phone-alt text-primary me-2"></small>
                <small>+998 91 426 9870</small>
            </div>
            <div class="h-100 d-inline-flex align-items-center">
                <a class="btn btn-sm-square bg-white text-primary me-1" href=""><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-sm-square bg-white text-primary me-1" href=""><i class="fab fa-twitter"></i></a>
                <a class="btn btn-sm-square bg-white text-primary me-1" href=""><i class="fab fa-linkedin-in"></i></a>
                <a class="btn btn-sm-square bg-white text-primary me-0" href=""><i class="fab fa-instagram"></i></a>
                <a class="btn btn-sm-square bg-white text-primary me-0" href="kirish.php"><i class="fa fa-lock"></i></a>

            </div>
        </div>
    </div>
</div>
<!-- Topbar End -->


<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
    <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 text-primary"> <i class="fa fa-users"></i>  Shirsholi MFY</h2>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.html" class="nav-item nav-link">Bosh sahifa</a>
            <a href="about.html" class="nav-item nav-link">Mahalla haqida</a>
            <a href="service.html" class="nav-item nav-link active">Mahalla pasporti</a>
            <a href="contact.html" class="nav-item nav-link">Contact</a>
        </div>
    </div>
</nav>
<!-- Navbar End -->


<!-- Page Header Start -->
<div class="container-fluid page-header py-5 mb-5 " style="background-image: url(img/mahalla8.jpg); height: 700px;">
    <div class="container py-5" >
        <h1 class="display-3 text-primary m-10 animated slideInDown" style="text-align: center;"> Shirsholi mahalla fuqarolar yig'inining pasporti </h1>
    </div>
</div>
<!-- Page Header End -->




<!--About Start -->
<div>
    <div class="container">
        <h4 class="text-center">Mahalla fuqarolar yig'ini xodimlari va jamoatchilik tuzilmalari to'g'risida ma'lumot</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>

                <th class="text-center col-lg-3" scope="col">Lavozimi</th>
                <th class="text-center col-lg-3" scope="col">F.I.SH</th>
                <th class="text-center col-lg-4" scope="col">Yashash manzili</th>
                <th class="text-center col-lg-2" scope="col">Telefon raqamii</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Fuqarolar yig'ini raisi</th>
                <th>Davlatov Rustambek</th>
                <th>Shirsholi mahallasi O.Ollaberganov ko'chasi 10-uy</th>
                <th>97-510-78-48</th>
            </tr>
            <tr>
                <th>Fuqarolar yig'ini raisining huquq-tartibot masalalari bo'yicha o'rinbosari - profilaktika (katta) inspektori</th>
                <th>Nurullaev Izzatbek Otamurod o'g'li</th>
                <th>Jaloil mahallasi Muruvvat ko'cha 31-uy</th>
                <th>99-115-35-58</th>
            </tr>
            <tr>
                <th>Fuqarolar yig'ini raisining oila, xotin-qizlar va ijtimoiy-ma'naviy masalalar bo'yicha o'rinbosari</th>
                <th>Masharipova Intizor Otamurod qizi</th>
                <th>Shirsholi mahallasi , Al-Xorazmiy ko'chasi 42-uy</th>
                <th>97-511-31-54</th>
            </tr>
            <tr>
                <th>Fuqarolar yig'ini raisining obodonlashtirish, tomorqa va tadbirkorlik masalalari bo'yicha o'rinbosari</th>
                <th>Jumaniyozova Malohat Jumanazarovna</th>
                <th>Shirsholi mahallasi , Yangiariq ko'chasi 8-uy</th>
                <th>97-515-78-50</th>
            </tr>
           
            <tr>
                <th>Fuqarolar yig'ini raisining yoshlar masalalari bo'yicha maslahatchisi</th>
                <th>Xajiev Mirzobek Nuraddin o'g'li</th>
                <th>Shirsholi mahallasi, Al-Xorazmiy ko'chasi 42-uy</th>
                <th>93-757-95-85</th>
            </tr>
            <tr>
                <th>Fuqarolar yig'ini raisining keksalar va faxriylar ishlari bo'yicha maslahatchisi</th>
                <th>Baxtiyorov Xudoyor Rupiyorovich</th>
                <th>Shirsholi mahallasi Tinchlik ko'chasi 7-uy</th>
                <th>94-779-18-05 </th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Demografik ko'rsatkichlar</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th class="col-lg-5 text-center" scope="col">Ko'rsatkichlar</th>
                <th class="text-center" scope="col">Jami</th>
                <th class="text-center" scope="col">Shundan ayollar</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Oilalar soni, birlik</th>
                <th class="text-center">910</th>
                <th class="text-center">x</th>
            </tr>
            <tr>
                <th>Xonadon soni, birlik</th>
                <th class="text-center">591</th>
                <th class="text-center">x</th>
            </tr>
            <tr>
                <th>Uy xo'jaliklari soni, birlik</th>
                <th class="text-center">609</th>
                <th class="text-center">x</th>
            </tr>
            <tr>
                <th>Axoli soni</th>
                <th class="text-center">3549</th>
                <th class="text-center">1756</th>
            </tr>
            <tr>
                <th>0-30 yosh</th>
                <th class="text-center">1764</th>
                <th class="text-center">845</th>
            </tr>
            <tr>
                <th>Shu jumladan:</th>
                <th class="text-center"></th>
                <th class="text-center"></th>
            </tr>
            <tr>
                <th>0-2 yosh</th>
                <th class="text-center">75</th>
                <th class="text-center">42</th>
            </tr>
            <tr>
                <th>3-6 yosh</th>
                <th class="text-center">178</th>
                <th class="text-center">329</th>
            </tr>
            <tr>
                <th>7-13 yosh</th>
                <th class="text-center">399</th>
                <th class="text-center">195</th>
            </tr>
            <tr>
                <th>14-17 yosh</th>
                <th class="text-center">349</th>
                <th class="text-center">168</th>
            </tr>
            <tr>
                <th>18-30 yosh</th>
                <th class="text-center">633</th>
                <th class="text-center">328</th>
            </tr>
            <tr>
                <th>Mehnatga layoqatli axoli soni(16-54 yoshli ayollar va 16-59 yoshli erkaklar)</th>
                <th class="text-center">1728</th>
                <th class="text-center">965</th>
            </tr>
            <tr>
                <th>Mehnatga layoqatli yoshdan yuqori aholi soni(55 yoshdan katta ayollar va 60 yoshdan katta erkaklar)</th>
                <th class="text-center">125</th>
                <th class="text-center">75</th>
            </tr>
            <tr>
                <th>Shundan(55 yoshdan katta faol nuroniy onaxonlar soni)</th>
                <th class="text-center">x</th>
                <th class="text-center">112</th>
            </tr>
            <tr>
                <th>100 yosh va undan kattalar soni</th>
                <th class="text-center">0</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Xaj va Umra safarlariga borgan fuqarolar</th>
                <th class="text-center">6 nafar</th>
                <th class="text-center">4 bafar</th>
            </tr>
            <tr>
                <th class="text-center">Aholining milliy tarkibi:</th>
                <th class="text-center">3549 nafar</th>
                <th class="text-center">1756 bafar</th>
            </tr>
            <tr>
                <th>O'zbek</th>
                <th class="text-center">3540 nafar</th>
                <th class="text-center">1751 bafar</th>
            </tr>
            <tr>
                <th>Qoraqalpoq</th>
                <th class="text-center">1 nafar</th>
                <th class="text-center">1 bafar</th>
            </tr>
            <tr>
                <th>rus</th>
                <th class="text-center">2 nafar</th>
                <th class="text-center">2 bafar</th>
            </tr>
            <tr>
                <th>tojik</th>
                <th class="text-center">0</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>tatar</th>
                <th class="text-center">1 nafar</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>turkman</th>
                <th class="text-center">5 nafar</th>
                <th class="text-center">2 nafar</th>
            </tr>
            <tr>
                <th>Fuqaroligi bo'lmagan shaxslar</th>
                <th class="text-center">0</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Fuqarolar yig'inida ro'yxatda turib, hozirgi kunda yashamayotganlar soni</th>
                <th class="text-center">9</th>
                <th class="text-center">4</th>
            </tr>
            <tr>
                <th>Fuqarolar yig'inida ro'yxatdan o'tmasdan yashayotganlar soni</th>
                <th class="text-center">12</th>
                <th class="text-center">5</th>
            </tr>
            <tr>
                <th>Tug'ilganlar soni</th>
                <th class="text-center">21</th>
                <th class="text-center">9</th>
            </tr>
            <tr>
                <th>Tuzilgan nikohlar soni, birlik</th>
                <th class="text-center">8 ta</th>
                <th class="text-center">x</th>
            </tr>
            <tr>
                <th>Vafot etganlar soni</th>
                <th class="text-center">14 ta</th>
                <th class="text-center">8 ta</th>
            </tr>
            <tr>
                <th>Doimiy yashash maqsadida ko'chib kelganlar soni</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Doimiy yashash maqsadida ko'chib kelganlar soni</th>
                <th class="text-center">1</th>
                <th class="text-center">2</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Axolining bandligi</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th scope="col" class="col-lg-8 text-center">Ko'rsatkichlar</th>
                <th scope="col" class="text-center">Kishi</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Korxona va tashkilotlarda ishlovchilar soni</th>
                <th class="text-center">463 nafar</th>
            </tr>
            <tr>
                <th>Tadbirkorlik bilan band bo'lganlar</th>
                <th class="text-center">272 nafar</th>
            </tr>
            <tr>
                <th>kasanachilik bilan band bo'lganlar soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>milliy hunarmandchilik bilan shug'ullanuvchilar soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>chorvachilik, parrandachilik va asalarichilik bilan band bo'lganlar soni</th>
                <th class="text-center">389 nafar</th>
            </tr>
            <tr>
                <th>tadbirkorlikning boshqa soxalarida band bo'lganlar soni</th>
                <th class="text-center">83 nafar</th>
            </tr>
            <tr>
                <th>Uzoq muddat xorijiy davlatlarga ish izlab ketganlar soni</th>
                <th class="text-center">289 nafar</th>
            </tr>
            <tr>
                <th>Ishlovchi mehnatga layoqatli yoshdan kichik (bolalar)lar soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Doimiy ish bilan band bo'lganlar soni</th>
                <th class="text-center">735 nafar</th>
            </tr>
            <tr>
                <th>Bola parvarishi bilan band bo'lganlar soni</th>
                <th class="text-center">81 nafar</th>
            </tr>
            <tr>
                <th>Talabalar soni</th>
                <th class="text-center">34 nafar</th>
            </tr>
            <tr>
                <th>Ishlovchi pensionerlar soni</th>
                <th class="text-center">14 nafar <br> 9nafar</th>
            </tr>
            <tr>
                <th>Ishsizlar soni</th>
                <th class="text-center">128 nafar</th>
            </tr>
            <tr>
                <th>kasb-hunar kollejlari bitiruvchilari soni</th>
                <th class="text-center">8 nafar</th>
            </tr>
            <tr>
                <th>oliy ta'lim muassasalari bitiruvchilari soni</th>
                <th class="text-center">6 nafar</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Aholining ijtimoiy holati</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th class="text-center col-lg-8" scope="col">Ko'rsatkichlar</th>
                <th class="text-center" scope="col">Kishi</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Boquvchisini yo'qotgan oilalar soni, birlik</th>
                <th class="text-center">7 nafar</th>
            </tr>
            <tr>
                <th>Yolg'iz onalar/otalar soni</th>
                <th class="text-center">5 nafar <br> 2 nafar</th>
            </tr>
            <tr>
                <th>Yolg'iz keksalar soni</th>
                <th class="text-center">4 nafar</th>
            </tr>
            <tr>
                <th>Kam ta'minlangan oilalar soni, birlik</th>
                <th class="text-center">31 ta</th>
            </tr>
            <tr>
                <th>2 yoshgacha nafaqa oluvchi oilalar soni, birlik</th>
                <th class="text-center">32 nafar</th>
            </tr>
            <tr>
                <th>14 yoshgacha nafaqa oluvchi oilalar soni, birlik</th>
                <th class="text-center">36 nafar</th>
            </tr>
            <tr>
                <th>moddiy yordam oluvchilar soni, birlik</th>
                <th class="text-center">10 nafar</th>
            </tr>
            <tr>
                <th>Ko'p bolali oilalar soni, birlik</th>
                <th class="text-center">2 ta</th>
            </tr>
            <tr>
                <th>Nogironligi bo'lgan shaxslar soni</th>
                <th class="text-center">75 nafar</th>
            </tr>
            <tr>
                <th>nogironlik nafaqasi oluvchilar soni</th>
                <th class="text-center">75 nafar</th>
            </tr>
            <tr>
                <th>Ikkinchi jahon urushi davrida front va front ortida qatnashgan hamda ularga tenglashtirilgan fuqarolar soni</th>
                <th class="text-center">2 nafar</th>
            </tr>
            <tr>
                <th>Baynalminal jangchilar va Chernobl' AES halokatini bartaraf etishda ishtirok etganlar soni</th>
                <th class="text-center">3 nafar</th>
            </tr>
            <tr>
                <th>Ijarada yashovchi fuqarolar soni</th>
                <th class="text-center">7 ta</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Ta'lim muassasalari to'g'risida</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th scope="col" class="text-center">Muassasa nomi</th>
                <th scope="col" class="text-center">Soni,<br>birlik</th>
                <th scope="col" class="text-center">O'quvchilar soni,<br>birlik</th>
                <th scope="col" class="text-center">shundan, mazkur MFYdan</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Maktabgacha ta'lim muassasalari</th>
                <th class="text-center">5 ta</th>
                <th class="text-center">237 nafar</th>
                <th class="text-center">191 nafar</th>
            </tr>
            <tr>
                <th>Maktablar</th>
                <th class="text-center">1 ta</th>
                <th class="text-center">1056 nafar</th>
                <th class="text-center">926 nafar</th>
            </tr>
            <tr>
                <th>Musiqa va San'at maktablari</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Bolalar va o'smirlar sport maktablari</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Ixtisoslashgan sport maktablari</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Litseylar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Kollejlar soni</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Texnikumlar soni</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Oliy o'quv yurtlari soni</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Boshqa hududdagi ta'lim muassasalariga qatnaydiganlar</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th scope="col" class="text-center">Muassasa nomi</th>
                <th scope="col" class="text-center">Soni,<br>birlik</th>
                <th scope="col" class="text-center">O'quvchilar soni,<br>birlik</th>
                <th scope="col" class="text-center">shundan, mazkur MFYdan</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Boshqa hududdagi ta'lim muassasalari boradiganlar, o'qiydiganlar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">65</th>
            </tr>
            <tr>
                <th>Maktabgacha ta'lim muassasalari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">12</th>
            </tr>
            <tr>
                <th>Maktablar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Musiqa va San'at maktablari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">3</th>
            </tr>
            <tr>
                <th>Bolalar va o'smirlar sport maktablari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">12</th>
            </tr>
            <tr>
                <th>Ixtisoslashgan sport maktablari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Litseylar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Kollejlar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Oliy o'quv yurtlari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">34</th>
            </tr>
            <tr>
                <th>Chet elda o'qiydiganlar soni</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">2</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Boshqa hududdagi ta'lim muassasalariga qatnaydiganlar</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th scope="col" class="text-center">Muassasa nomi</th>
                <th scope="col" class="text-center">Soni,<br>birlik</th>
                <th scope="col" class="text-center">O'quvchilar soni,<br>birlik</th>
                <th scope="col" class="text-center">shundan, mazkur MFYdan</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Boshqa hududdagi ta'lim muassasalari boradiganlar, o'qiydiganlar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">65</th>
            </tr>
            <tr>
                <th>Maktabgacha ta'lim muassasalari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">12</th>
            </tr>
            <tr>
                <th>Maktablar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Musiqa va San'at maktablari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">3</th>
            </tr>
            <tr>
                <th>Bolalar va o'smirlar sport maktablari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">12</th>
            </tr>
            <tr>
                <th>Ixtisoslashgan sport maktablari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Litseylar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Kollejlar</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">0</th>
            </tr>
            <tr>
                <th>Oliy o'quv yurtlari</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">34</th>
            </tr>
            <tr>
                <th>Chet elda o'qiydiganlar soni</th>
                <th class="text-center">x</th>
                <th class="text-center">x</th>
                <th class="text-center">2</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Ijtimoiy-ma'naviy muhit bilan bog'liq ko'rsatkichlar</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th></th>
                <th class="col-lg-5 text-center" scope="col">Jami,<br>birlik</th>
                <th class="text-center" scope="col">Ayollar,<br>birlik</th>
                <th class="text-center" scope="col">Voyaga yetmaganlar,<br>birlik</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Notinch oilalar</th>
                <th class="text-center">2 ta</th>
                <th class="text-center">2</th>
                <th class="text-center">4</th>
            </tr>
            <tr>
                <th>Noqobil oilalar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Sodir etilgan huquqbuzarliklar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Sodir etilgan jinoyatlar</th>
                <th class="text-center">2 ta</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>JEMda jazo o'tayotganlar</th>
                <th class="text-center">2 nafar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>JEMda jazo muddati o'tab qaytganlar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Ozodlikdan mahrum qilish bilan bog'liq bo'lmagan jazolarni o'tayotgan mahkumlar soni</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>O'z joniga qasd va suiqasd holatlari</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Chet el davlatlaridan deportasiya qilinganlar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Odam savdosi bilan bog'liq jinoyatlardan jabr ko'rganlar soni</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Jami profilaktik hisobda turgan shaxslar</th>
                <th class="text-center">3 nafar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Profilaktik hisobda turgan fohisha ayollar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Profilaktik hisobda turgan qo'shmachilar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Profilaktik hisobda turgan ijtimoiy ko'makka muhtoj shaxslar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Sog'liqni saqlash muassasalari hisobida turganlar</th>
                <th class="text-center">112</th>
                <th class="text-center">59</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Giyohvandlar</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Spirtli ichimlikka ruju qo'ygan shaxslar</th>
                <th class="text-center">3 ta</th>
                <th class="text-center">Yo'q</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Ruhiy kasallar</th>
                <th class="text-center">11 nafar</th>
                <th class="text-center">4 nafar</th>
                <th class="text-center">Yo'q</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Qishloq xo'jaligi bilan bog'liq ko'rsatkichlar</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th class="col-lg-8" scope="col"></th>
                <th class="text-center" scope="col">Birlik</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Dehqon xo'jaliklari soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Dehqon xo'jaliklari yer maydoni, ga</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Tomorqasi bor hovlilar soni</th>
                <th class="text-center">423 nafar</th>
            </tr>
            <tr>
                <th>Tomorqasi bor hovlilarning umumiy maydoni, ga</th>
                <th class="text-center">25.3 ga</th>
            </tr>
            <tr>
                <th>shundan ekin maydoni, ga</th>
                <th class="text-center">12.6 ga</th>
            </tr>
            <tr>
                <th>Tomorqasida issiqxona va parniklar bor oilalar soni</th>
                <th class="text-center">25 nafar</th>
            </tr>
            <tr>
                <th>shundan issiqxona va parnik maydoni (ga)</th>
                <th class="text-center">0,15 ga</th>
            </tr>
            <tr>
                <th>Umumiy tomorqa maydoni (Ga)</th>
                <th class="text-center">0,15 ga</th>
            </tr>
            <tr>
                <th>Tomorqasida issiqxona va parniklar bor oilalar soni</th>
                <th class="text-center">25 nafar</th>
            </tr>
            <tr>
                <th>shundan issiqxona va parnik maydoni (ga)</th>
                <th class="text-center">0,15 ga</th>
            </tr>
            <tr>
                <th>Tomorqadan unumli foydalanayotgan xonadonlar soni</th>
                <th class="text-center">423  nafar</th>
            </tr>
            <tr>
                <th>Tomorqadan unumli foydalanmayotgan xonadonlar soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>shundan rasmiy ogohlantirish berilganlar soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>yer solig'i miqdorini 3 baravar oshirib to'lash chorasi ko'rilganlar soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Chorvachilik bilan shug'ullanadigan xonadonlar soni</th>
                <th class="text-center">225 ta</th>
            </tr>
            <tr>
                <th>shundan:</th>
                <th class="text-center"></th>
            </tr>
            <tr>
                <th>yirik shoxli qoramollar, bosh</th>
                <th class="text-center">286 bosh</th>
            </tr>
            <tr>
                <th>qo'y va echkilar, bosh</th>
                <th class="text-center">25 bosh</th>
            </tr>
            <tr>
                <th>otlar, bosh</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>eshaklar, bosh</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>tuyalar, bosh</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>cho'chqalar, bosh</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Mo'ynali hayvonlar, bosh</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Parrandachilik bilan shug'ullanadigan xonadonlar soni</th>
                <th class="text-center">351 ta</th>
            </tr>
            <tr>
                <th>jami uy parrandalari soni</th>
                <th class="text-center">2055 ta</th>
            </tr>
            <tr>
                <th>Quyonchilik bilan shug'ullanadigan xonadonlar soni</th>
                <th class="text-center">12</th>
            </tr>
            <tr>
                <th>quyonlar soni, bosh</th>
                <th class="text-center">48</th>
            </tr>
            <tr>
                <th>Asalarichilik bilan shug'ullanadigan xonadonlar  soni</th>
                <th class="text-center">2 ta</th>
            </tr>
            <tr>
                <th>jami asalari oilalari (uyalar) soni</th>
                <th class="text-center">75 ta</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Fuqarolar yig'ini to'g'risida ma'lumot</h4>
        <table class="table table-bordered border-dark">
            <tbody>
            <tr>
                <th>Fuqarolar yig'ini idorasi joylashgan manzili va telefon raqami (Yuridik manzil to'liq ko'rsatilishi lozim)</th>
                <th>Ogahiy  maxalla fuqarolar yig'in Mustaqillik ko'chasi  23 uy</th>
            </tr>
            <tr>
                <th>Fuqarolar yig'ini joylashgan xizmat bino haqida (Yig'in balansiga olingan bo'lsa, sanasi va raqami, shuningdek, olinmagan bo'lsa, qaysi tashkilot balansidaligi to'liq ko'rsatilishi lozim)</th>
                <th>Yig'in Yangiariq tuman xokimligi balansidagi binoda faoliyat yuritib keladi</th>
            </tr>
            <tr>
                <th>Mahalliy hokimlikning fuqarolar yig'inini tashkil etish to'g'risidagi qarori raqami va sanasi. Shuningdek, davlat xizmatlari markazi, soliq inspeksiyasi tomonidan berilgan guvohnoma raqami va sanasi (To'liq ko'rsatilishi lozim)</th>
                <th>2012 yil 25 maydagi №324-q-sonli qaror</th>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h4 class="text-center">Fuqarolar yig'inining moddiy-texnika bazasining holati</h4>
        <table class="table table-bordered border-dark">
            <thead>
            <tr>
                <th class="col-lg-8" scope="col"></th>
                <th class="text-center" scope="col">Birlik</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Xizmat binosi umumiy maydoni, kv.m.</th>
                <th class="text-center">56 Kv.m</th>
            </tr>
            <tr>
                <th>shundan qurilish osti maydoni, kv.m.</th>
                <th class="text-center">56 Kv.m</th>
            </tr>
            <tr>
                <th>Xizmat xonalari soni</th>
                <th class="text-center">2 ta</th>
            </tr>
            <tr>
                <th>shundan kutubxona mavjudligi</th>
                <th class="text-center">Mavjud emas</th>
            </tr>
            <tr>
                <th>Kutubxonadagi adabiyotlar soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>shundan majlislar zali mavjudligi</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Komp'yuter soni</th>
                <th class="text-center">1 ta</th>
            </tr>
            <tr>
                <th>Noutbuk, netbuk, planshet soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Internet tarmog'iga ulanganligi (TAS/IX)</th>
                <th class="text-center">ulangan</th>
            </tr>
            <tr>
                <th>Nusxa ko'chirish apparati soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Printer soni</th>
                <th class="text-center">1 ta</th>
            </tr>
            <tr>
                <th>Skaner soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Kondisioner soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Xizmat telefoni soni</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Faks apparati</th>
                <th class="text-center">Yo'q</th>
            </tr>
            <tr>
                <th>Mebel soni</th>
                <th class="text-center">15 ta</th>
            </tr>
            <tr>
                <th>shkaf</th>
                <th class="text-center">1 ta</th>
            </tr>
            <tr>
                <th>stol</th>
                <th class="text-center">2 ta</th>
            </tr>
            <tr>
                <th>stul</th>
                <th class="text-center">12 ta</th>
            </tr>
            <tr>
                <th>Uslubiy adabiyotlar soni</th>
                <th class="text-center">61 ta</th>
            </tr>
            <tr>
                <th>isitish tizimi mavjudligi</th>
                <th class="text-center">Mavjud emas</th>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<!-- About End -->





<!-- Footer Start -->
<div class="container-fluid bg-dark text-light footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-3 col-md-6">
                <h4 class="text-light mb-4">Bog`lanish</h4>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Xorazm, Yangiariq, Shirsholi</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+998 91 426 9870</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>shirsholiMFY@gmail.com</p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <h4 class="text-light mb-4">Tez havolalar</h4>
                <a class="btn btn-link" href="">Bosh sahifa</a>
                <a class="btn btn-link" href="">Mahalla haqida</a>
                <a class="btn btn-link" href="">Biz bilan bog`lanish</a>
            </div>
            <div class="col-lg-3 col-md-6">
                <h4 class="text-light mb-4">Ommabop havolalar</h4>
                <a class="btn btn-link" href="">Bosh sahifa</a>
                <a class="btn btn-link" href="">Mahalla haqida</a>
                <a class="btn btn-link" href="">Biz bilan bog`lanish</a>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->


<!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/isotope/isotope.pkgd.min.js"></script>
<script src="lib/lightbox/js/lightbox.min.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>
</body>

</html>


