<?php
$role=1;
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kurs_ishi";

$conn = new mysqli($servername, $username, $password, $dbname);

if (!$conn) {
    die("Xatolik" . mysqli_connect_error());
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--    Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--    Font Awersome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>List of requests</title>
</head>
<body>

<div style="background-color:green; padding: 30px 0; text-align:center;" >
    <h2>PHP Complate Crud Aplication</h2>
</div>
<div class="container">
    <table class="table table-hover text-center mt-5">
        <thead class="table-dark ">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Ism familiya</th>
            <th scope="col">Email</th>
            <th scope="col">Telefon raqam</th>
            <th scope="col">Murojat mavzusi</th>
            <th scope="col">Maxsus eslatma</th>
            <th scope="col">Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kurs_ishi";

$conn = new mysqli($servername, $username, $password, $dbname);

        $sql="SELECT * FROM `xabar` ";

        $result=mysqli_query($conn,$sql);
        while ($row=mysqli_fetch_assoc($result)){
             ?>
             <th><?php echo $row['id'] ?></th>
            <th><?php echo $row['fullname'] ?></th>
            <th><?php echo $row['email'] ?></th>
            <th><?php echo $row['phone'] ?></th>
            <th><?php echo $row['murojat_mavzu'] ?></th>
            <th><?php echo $row['maxsus_eslatma'] ?></th>
            <th><a href="delete.php?id=<?php echo $row['id']?>" class="link-dark"><i class="fa-solid fa-trash fs-5 "></i></a></th>

            </tr>
                    <?php } ?>

        </tbody>
    </table>

    <div><a href="index.php" style="background-color:red;padding:15px 25px;text-decoration:none;color:white;position:absolute; bottom:50px;">Chiqish</a></div>

</div>


<!--Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>