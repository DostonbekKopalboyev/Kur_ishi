<?php


require_once 'connect.php';

global $conn;
$sql="SELECT * FROM `table2` ";

$result=mysqli_query($conn,$sql);

//create an array
$emparray = array();
while($row =mysqli_fetch_assoc($result))
{
    echo json_encode($row)."<br>";
}


